package com.lti.practice;

public class Carnivores implements Animal {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Animal eat meat");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("Animal sleep on meat");
	}
	
}
