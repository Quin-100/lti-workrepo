package com.lti.practice;

public class Herbivores  implements Animal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Animal eat grass");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("Animal sleep on grass");
	}
	
}
