package com.lti.banking;

public abstract class Person {
	
	public abstract void eat();
	public abstract void sleep();
	
}
