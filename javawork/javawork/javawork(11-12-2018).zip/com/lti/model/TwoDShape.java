package com.lti.model;

public abstract class TwoDShape extends Shape {

}
