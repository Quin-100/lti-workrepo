package com.lti.model;

public class IsocellesTriangle extends Triangle {
	public void draw () {		
		System.out.println("IsocellesTriangle  is enjoying");
	}
}
