package com.lti.model.inheritance;

public class Gadget {
	protected String manufacturer;
	protected double price;
	protected int yom;
	protected int OS;
	
	
	public void turnOn() {};
	public void turnOff() {};
	
	
	
}
