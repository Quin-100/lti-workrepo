package com.lti.model;

public interface Publishable extends Printable {
	
	public void  publish();

}
