package com.lti.model;

public interface Printable {
	public void print();
}
