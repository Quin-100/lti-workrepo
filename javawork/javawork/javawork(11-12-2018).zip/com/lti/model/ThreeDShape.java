package com.lti.model;

public abstract class ThreeDShape extends Shape {
	
}
