package com.lti.threads;

public class RunnableRacer implements Runnable {	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub		
		System.out.println("Hell yeahhh...");
			
	}

}
