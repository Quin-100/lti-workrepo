package com.lti.threads;

public class Data {
	
	private String msg;
	
	public Data(String msg) {
		super();
		this.msg = msg;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
