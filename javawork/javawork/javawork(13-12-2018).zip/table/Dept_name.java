package com.lti.table;

public enum Dept_name {
	
	IT,
	HR,
	Executive,
	Sales,
	Manager

}
